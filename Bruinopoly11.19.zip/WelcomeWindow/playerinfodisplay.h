#ifndef PLAYERINFODISPLAY_H
#define PLAYERINFODISPLAY_H
#include <QLabel>
#include <QWidget>
#include <QGridLayout>
#include "statics.h"
//everthing inside a template is a duck typed
class PlayerInfoDisplay : public QWidget
{
    Q_OBJECT

public:
    explicit PlayerInfoDisplay(QWidget *parent = nullptr, int a=4, const QStringList& b={}, const QStringList& c={},const Statics& d=Statics());
    QStringList PlayerNames();

private:
    QLabel *createPlayerHeader(const QString& text);
    QLabel *createPlayerPixmap(const QString &text);
    const int numofplayer;
    QStringList names;
    QStringList charactors;
    //enum{BoardLength = 4};
    //QLabel *playertext[BoardLength];
    //QLabel *playerPixmap[BoardLength];
    QVector<QLabel *>playertext;
    QVector<QLabel *>playerPixmap;
    Statics s;
    friend class MainWindow;
};

#endif // PLAYERINFODISPLAY_H
