#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGroupBox>
#include <QBoxLayout>
#include "gameboard.h"
#include "playerinfodisplay.h"
//#include "player.h"
#include "statics.h"
//#include "property.h"
//#include"bank.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr, int a=4, const QStringList& b={}, const QStringList& c={},const Statics& d=Statics());

private:
    GameBoard *boardArea;
    PlayerInfoDisplay *playerArea;
    int numofplayer;
    QStringList names;
    QStringList charactors;
    //QVector<Player*>playerlist;
    //Property* property;
    //Bank* bank;
    Statics s;
    friend class subWindow;

};
#endif // MAINWINDOW_H
