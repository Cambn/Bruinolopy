#include "movement.h"
#include <QDebug>

Movement::Movement(QWidget *parent,int order, int money, QString address) :
    QWidget(parent),position(0),modify_x(order),money(money)
{
    for (int i=0;i<12;i++){
        xAxis[i]+=(width+5)*modify_x;
    }
    Img = new QPixmap(address);
    ImgRect = new QRect(xAxis[position],yAxis[position], width, height);

    //@rect: area that could be drawn on
    QRect rect = this->geometry ();
    rect.setWidth (width*150);
    rect.setHeight (height*150);
    rect.setX(0);
    rect.setY(0);
    this ->setGeometry(rect);
}


void Movement::paintEvent(QPaintEvent*)
{
        QPainter painter(this);
        painter.drawPixmap(*ImgRect, *Img);
}

void Movement::walkbydice(){
    d->rollStart->hide();
    timer=new QTimer(this);
    timer->start(250);
    QObject::connect(timer,SIGNAL(timeout()),this,SLOT(one_step()));
    if (position/12<(position+d->getresult())/12)
        money+=increment;
}

void Movement::one_step(){
    if (step_walked<d->getresult()){
        position+=1;
        ImgRect ->setX(xAxis[position%12]);
        ImgRect ->setY(yAxis[position%12]);
        ImgRect->setHeight(height);
        ImgRect->setWidth(width);
        repaint();
        step_walked++;
    }
    else
    {
        QObject::connect(timer,SIGNAL(timeout()),this,SLOT(showrollbutton()));
        timer->stop();
        timer->start(250);
    }

}

void Movement::showrollbutton(){
    d->rollStart->show();
    timer->stop();
    step_walked=0;
}



Movement::~Movement()
{
    delete Img;
    delete ImgRect;
    delete timer;
    delete timer2;

}


