#ifndef WELCOMEWINDOW_H
#define WELCOMEWINDOW_H

#include <QObject>
#include <QLayout>
#include <QWidget>
#include <QSize>
#include <QMediaPlayer>
#include <QPushButton>

class WelcomeWindow : public QWidget
{
    Q_OBJECT
public:
    explicit WelcomeWindow(QWidget *parent = nullptr);
    ~WelcomeWindow(){delete music; delete sound;}

private:
    QSize sizeHint() const;//set the initial window size
    void resizeEvent(QResizeEvent *evt);//resize the background when window size changed
    QPushButton* sound;
    QMediaPlayer* music;
    void GeneralBtnSetup(QPushButton* &b, QHBoxLayout* &btnlayout);

signals:

public slots:
    void soundclick();
};

#endif // WELCOMEWINDOW_H
