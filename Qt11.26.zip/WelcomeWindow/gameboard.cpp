#include "gameboard.h"


GameBoard::GameBoard(QWidget *parent):QWidget(parent){
    QGridLayout *mainLayout = new QGridLayout(this);

    //create blocks
    for(int column = 0; column<BoardLength; ++column){
        for(int row = 0; row< BoardWidth; ++row){
            pixmapLabels[column][row] = createPixmapLabel();
            pixmapLabels[column][row]->setParent(this);
            mainLayout ->addWidget(pixmapLabels[column][row], row+1, column+1);
        }
    }
    for(int column = 0; column<BoardLength; ++column){
        for(int row = 0; row< BoardWidth; ++row){
            pixmapLabels[column][row]->setFixedSize(pixmapLabels[0][0]->size());
        }
    }

    for(int column = 1; column<BoardLength-1; ++column){
        for(int row = 1; row< BoardWidth-1; ++row){
           pixmapLabels[column][row]->hide();
       }
    }

    QPixmap bg=  QPixmap(":/fig/chancecard.png");
    pixmapLabels[0][0]->setPixmap(bg.scaled(pixmapLabels[0][0]->width(), pixmapLabels[0][0]->height(), Qt::IgnoreAspectRatio));

}

QLabel *GameBoard::createPixmapLabel(){
    QLabel *label = new QLabel(this);
    label ->setAlignment(Qt::AlignCenter);
    label ->setFrameShape(QFrame::Box);
    label ->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    label ->setBackgroundRole(QPalette::Base);
    label ->setAutoFillBackground(true);
    label ->setMinimumSize(1488/BoardWidth,520/BoardLength);
    return label;
}


