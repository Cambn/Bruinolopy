#ifndef CHANCECARD_H
#define CHANCECARD_H
#include <QWidget>
#include <QMdiArea>
#include <QLabel>
#include <QPixmap>
#include <QLayout>
#include <QTime>
#include "player.h"

//class bank

class ChanceCard : public QWidget
{
    Q_OBJECT
public:
   ChanceCard(QWidget *parent = nullptr);

private:
   QStringList cardcontent={"Money -200","Money +300","Money+800","Money -600"};


public slots:
    void conduct_change(Player* p);

};

#endif // CHANCECARD_H
