#include "welcomewindow.h"
#include "dice.h"


//Yuxin Qian
//Group members: Hao Zheng, Daniel Becerra, Yuxin Qian, Chuqi Bian
//"I pledge that I have neither given nor received unauthorized assistance on this assignment."

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   WelcomeWindow w;
   /* QStringList names;
    QStringList charactors;
    for (int i=0;i<2;i++){
        names.append("john");
        charactors.append("panda");
    }

    MainWindow w(nullptr,2,names,charactors);*/
    w.show();
    return a.exec();
}
