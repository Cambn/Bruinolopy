#include "chancecard.h"
#include <QDialog>

ChanceCard::ChanceCard(QWidget *parent):QWidget(parent){
}

void ChanceCard::conduct_change(Player* p){
    QWidget* content = new QDialog(this);
    content->setAttribute(Qt::WA_DeleteOnClose);
    QHBoxLayout* layout = new QHBoxLayout;
    QLabel* bearlb = new QLabel;
    QLabel* statement = new QLabel;
    bearlb->setFixedSize(150,180);
    QPixmap *bear = new QPixmap(":/fig/chance_deco.png");
    bearlb->setPixmap(*bear);
    bearlb->setPixmap(bear->scaled(bearlb->width(), bearlb->height(), Qt::KeepAspectRatio));
    layout->addWidget(bearlb,0,Qt::AlignRight);
    QPalette pal = palette();
    pal.setColor(QPalette::Background, Qt::white);
    content->setAutoFillBackground(true);
    content->setPalette(pal);
    content->setFixedSize(400,200);

    qsrand(time(0));
    int result = qrand()% 4;
    statement->setText(cardcontent[result]);
    layout->addWidget(statement);
    content->setLayout(layout);
    content->setWindowTitle("Chance Card");
    content->show();

    //"Money-200","Money+300","Money+800","Money-600","STUDY ROOM"
    if(result==0){
        p->getmovement()->increaseMoney(-200);
    }
    else if(result==1){p->getmovement()->increaseMoney(300);}
    else if(result==2){p->getmovement()->increaseMoney(800);}
    else if(result==3){p->getmovement()->increaseMoney(-600);}


}
