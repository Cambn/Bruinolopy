#ifndef MOVEMENT_H
#define MOVEMENT_H

#include <QPainter>
#include <QTimer>
#include <QDateTime>
#include "dice.h"

//the movement class is part of the player class
//it tracks the dice, the position

class Movement : public QWidget
{
    Q_OBJECT

public:
    friend class GameBoard;
    explicit Movement(QWidget *parent = nullptr,int order=0,int money=0, QString address=":/fig/gb_panda.png");
    Dice* d;//a shallow copy to maindice
    void paintEvent(QPaintEvent *event) override;
    void increaseMoney(int a){money+=a;}
    int getmoney() const {return money;}
    int getpos() const {return position;}
    //void changePos(int a){position=a;}



public slots:
    void walkbydice();
    void one_step();
    void showrollbutton();

private:

    QTimer* timer;
    QPixmap *Img;
    QRect *ImgRect;//the size of the drawn pic
    int position;
    int order;//modify the x value to avoid icon shown overlapped
    int money;
    const int width=80;
    const int height=120;
    const int yAxis[12]={435,435,435,435,295,155,15,15,15,15,155,295};
    int xAxis[12]={15,397,779,1161,1161,1161,1161,779,397,15,15,15};
    int step_walked=0;
    QString Img_address;
    const int increment=1000;//if bank has money
};

#endif // MOVEMENT_H
