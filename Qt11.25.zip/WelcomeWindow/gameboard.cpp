#include "gameboard.h"


GameBoard::GameBoard(QWidget *parent):QWidget(parent){
    QGridLayout *mainLayout = new QGridLayout(this);
    for(int column = 0; column<BoardLength; ++column){
        for(int row = 0; row< BoardWidth; ++row){
            pixmapLabels[column][row] = createPixmapLabel();
            pixmapLabels[column][row]->setParent(this);
            mainLayout ->addWidget(pixmapLabels[column][row], row+1, column+1);
        }
    }
     pixmapLabels[1][1]->hide();
     pixmapLabels[2][1]->hide();
     pixmapLabels[1][2]->hide();
     pixmapLabels[2][2]->hide();

     pixmapLabels[3][1]->setFixedSize(pixmapLabels[3][1]->size());
     QPixmap bg=  QPixmap(":/fig/chancecard.png");
     pixmapLabels[3][1]->setPixmap(bg.scaled(pixmapLabels[3][1]->width(), pixmapLabels[3][1]->height(), Qt::IgnoreAspectRatio));

}

QLabel *GameBoard::createPixmapLabel(){
    QLabel *label = new QLabel(this);
    label ->setAlignment(Qt::AlignCenter);
    label ->setFrameShape(QFrame::Box);
    label ->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    label ->setBackgroundRole(QPalette::Base);
    label ->setAutoFillBackground(true);
    label ->setMinimumSize(372,130);
    return label;
}


